if (typeof firebase === 'undefined') throw new Error('hosting/init-error: Firebase SDK not detected. You must include it before /__/firebase/init.js');
firebase.initializeApp({
  "apiKey": "AIzaSyBBY2K2rvw9eOBljbSMZ1LDAEeCks67wnM",
  "authDomain": "murtaza-k.firebaseapp.com",
  "databaseURL": "",
  "messagingSenderId": "385988531863",
  "projectId": "murtaza-k",
  "storageBucket": "murtaza-k.appspot.com"
});